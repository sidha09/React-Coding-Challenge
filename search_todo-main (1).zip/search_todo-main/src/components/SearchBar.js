import React from 'react';

const SearchBar = () => {
    return (
        <div className="container">
            <div className="form-group">
                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Search Todo..." />
            </div>
        </div>
    )
}

export default SearchBar;
